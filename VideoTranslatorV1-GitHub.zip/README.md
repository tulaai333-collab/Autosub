# VideoTranslatorV1

## Build with GitHub Actions
1. Create a GitHub repository.
2. Upload the project files to the repository.
3. Open **Actions**.
4. Select **Build Android APK**.
5. Press **Run workflow**.
6. Open the completed run and download **VideoTranslatorV1-debug**.
