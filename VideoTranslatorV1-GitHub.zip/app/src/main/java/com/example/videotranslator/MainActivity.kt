package com.example.videotranslator

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var selectedVideo: Uri? = null

    private val pickVideo =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                selectedVideo = uri
                findViewById<TextView>(R.id.txtVideo).text =
                    "Video: ${getFileName(uri)}"
                findViewById<TextView>(R.id.txtStatus).text =
                    "Đã chọn video. Bây giờ nhập phụ đề tiếng Việt."
            }
        }

    private val createSrt =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/x-subrip")) { uri ->
            if (uri != null) {
                val title = findViewById<EditText>(R.id.edtTitle).text.toString()
                    .ifBlank { "translated_video" }
                val text = findViewById<EditText>(R.id.edtSubtitle).text.toString()

                val srt = makeSrt(text)

                contentResolver.openOutputStream(uri)?.use { output ->
                    output.write(srt.toByteArray(Charsets.UTF_8))
                }

                findViewById<TextView>(R.id.txtStatus).text =
                    "Đã xuất $title.srt thành công."
                Toast.makeText(this, "Xuất phụ đề thành công", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnChooseVideo).setOnClickListener {
            pickVideo.launch("video/*")
        }

        findViewById<Button>(R.id.btnExport).setOnClickListener {
            val text = findViewById<EditText>(R.id.edtSubtitle).text.toString().trim()

            if (selectedVideo == null) {
                Toast.makeText(this, "Hãy chọn video trước.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (text.isEmpty()) {
                Toast.makeText(this, "Hãy nhập phụ đề trước.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val title = findViewById<EditText>(R.id.edtTitle).text.toString()
                .ifBlank { "translated_video" }

            createSrt.launch("$title.srt")
        }
    }

    private fun makeSrt(text: String): String {
        val lines = text.lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        if (lines.isEmpty()) return ""

        val sb = StringBuilder()

        // V1 dùng thời lượng mặc định 4 giây/câu.
        // V2 sẽ thay bằng timeline lấy tự động từ nhận diện giọng nói.
        lines.forEachIndexed { index, line ->
            val start = index * 4
            val end = start + 4

            sb.append(index + 1).append("\n")
            sb.append(formatTime(start)).append(" --> ")
                .append(formatTime(end)).append("\n")
            sb.append(line).append("\n\n")
        }

        return sb.toString()
    }

    private fun formatTime(seconds: Int): String {
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return String.format("%02d:%02d:%02d,000", h, m, s)
    }

    private fun getFileName(uri: Uri): String {
        var result = "video"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIndex >= 0) {
                result = cursor.getString(nameIndex)
            }
        }
        return result
    }
}
